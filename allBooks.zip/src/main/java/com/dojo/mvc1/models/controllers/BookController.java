package com.dojo.mvc1.models.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dojo.mvc1.models.Book;
import com.dojo.mvc1.services.BookService;

@Controller //****renders jsp page, return String that is name of jsp file
public class BookController {
	
	@Autowired //****auto sets dependency injection
	BookService bookService;

	@RequestMapping("/")
	public String home(Model model) {
		return "redirect:/books";
	}
	
	@RequestMapping("/books/{id}")
	public String index(Model model, @PathVariable("id") Long id) {
		
		System.out.println(id);
		Book book = bookService.findBook(id);
		System.out.println(book);
		
		model.addAttribute("book", book);
		
		return "show.jsp";
	}
	
	@RequestMapping("/books")
	public String index(Model model) {
		List<Book> books = bookService.allBooks();
		model.addAttribute("books", books);
		return "/index.jsp";
	}
	
}
